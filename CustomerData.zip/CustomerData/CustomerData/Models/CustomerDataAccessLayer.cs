﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerData.Models
{
    public class CustomerDataAccessLayer
    {
        //string connectionString = "Put Your Connection string here";

        string connectionString = "Data Source = et3ws6434; Initial Catalog = customer; Integrated Security = SSPI;User ID = sa;Password=effective1?;";
        //To View all employees details    
        public IEnumerable<Customer> GetAllCustomer()
        {
            List<Customer> lstcust = new List<Customer>();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("spGetAllcustomer", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Customer cust = new Customer();
                    cust.ID = Convert.ToInt32(rdr["ID"]);
                    cust.Name = rdr["Name"].ToString();
                    cust.Surname = rdr["Surname"].ToString();
                    cust.TelephoneNumber = rdr["TelephoneNumber"].ToString();
                    cust.Address = rdr["Address"].ToString();
                    lstcust.Add(cust);
                }
                con.Close();
            }
            return lstcust;
        }
        //To Add new Customer record    
        public void AddCustomer(Customer customer)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("spAddCustomer", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Name", customer.Name);
                cmd.Parameters.AddWithValue("@Surname",customer.Surname);
                cmd.Parameters.AddWithValue("@TelephoneNumber", customer.TelephoneNumber);
                cmd.Parameters.AddWithValue("@Address", customer.Address);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
        //To Update the records of a particluar employee  
        public void UpdateCustomer(Customer customer)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("spUpdatecustomer", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", customer.ID);
                cmd.Parameters.AddWithValue("@Name", customer.Name);
                cmd.Parameters.AddWithValue("@Surname", customer.Surname);
                cmd.Parameters.AddWithValue("@TelephoneNumber", customer.TelephoneNumber);
                cmd.Parameters.AddWithValue("@Address", customer.Address);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
        //Get the details of a particular employee  
        public Customer GetCustomerData(int? id)
        {
            Customer customer = new Customer();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string sqlQuery = "SELECT * FROM customer WHERE isactive='1'and ID= " + id;
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    customer.ID = Convert.ToInt32(rdr["ID"]);
                    customer.Name = rdr["Name"].ToString();
                    customer.Surname = rdr["Surname"].ToString();
                    customer.TelephoneNumber = rdr["TelephoneNumber"].ToString();
                    customer.Address = rdr["Address"].ToString();
                }
            }
            return customer;
        }
        //To Delete the record on a particular employee  
        public void DeleteCustomer(int? id)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("spDeletecustomer", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", id);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
    }
}